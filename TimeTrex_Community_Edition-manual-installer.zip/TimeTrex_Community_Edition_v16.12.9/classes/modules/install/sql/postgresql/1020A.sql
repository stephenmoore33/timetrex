alter table premium_policy add column include_partial_punch smallint NOT NULL DEFAULT 0;
