ALTER TABLE recurring_holiday ADD COLUMN always_week_day_id integer DEFAULT 0;
