ALTER TABLE message_control ALTER COLUMN body TYPE text;
