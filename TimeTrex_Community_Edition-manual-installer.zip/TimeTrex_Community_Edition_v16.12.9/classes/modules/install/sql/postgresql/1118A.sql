alter table "meal_policy" add column allocation_type_id smallint default 10;
alter table "break_policy" add column allocation_type_id smallint default 10;