alter table "pay_period_schedule" add column time_zone character varying;

