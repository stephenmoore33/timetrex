ALTER TABLE accrual_policy ADD COLUMN apply_frequency_hire_date smallint NOT NULL DEFAULT 0;

