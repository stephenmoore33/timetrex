ALTER TABLE user_preference ADD COLUMN default_login_screen CHARACTER VARYING NOT NULL DEFAULT 'Home';
