CREATE UNIQUE INDEX authentication_session_id ON authentication(session_id);
