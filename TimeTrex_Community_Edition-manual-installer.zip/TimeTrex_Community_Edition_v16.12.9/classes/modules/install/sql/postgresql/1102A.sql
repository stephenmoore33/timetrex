ALTER TABLE holiday_policy ADD COLUMN average_time_frequency_type_id smallint DEFAULT 10;
