alter table station add enable_auto_punch_status smallint DEFAULT 0 NOT NULL;
alter table station add mode_flag bigint DEFAULT 1 NOT NULL;