alter table "punch" add column longitude numeric(15,10);
alter table "punch" add column latitude numeric(15,10);
